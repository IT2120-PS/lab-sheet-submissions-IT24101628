setwd("C://Users//it24101628//Desktop//IT24101628_Lab_04")
getwd()

# Check the files in the directory
print(list.files("C://Users//it24101628//Desktop//IT24101628_Lab_04"))

##01 - Load data
branch_data <- read.table("Exercise.txt", header = TRUE,SEP=",")
head(branch_data)  # Checks the first few rows

##02 - Sales_X1 = Qualitative, Advertising_X2 = Quantitative, Years_X3 = Quantitative

##03 - Boxplot 
boxplot(branch_data$Sales,main = "Boxplot OF Sales", ylab = "Sales",col = "lightblue")

##04 - IQR for Advertising
fivenum(branch_data$Advertising)
summary(branch_data$Advertising)
IQR(branch_data$Advertising)

##05 - Outlier function
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  low <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  outliers <- x[x < low | x > upper]
  return(outliers)
  
}
find_outliers(braanch_data_Years)

